
# Práctica independiente 

Para la práctica independiente sobre el modelo lineal les compartimos el material práctico del curso de [Enfoque Estadístico del Aprendizaje](https://diegokoz.github.io/EEA2019/):

- [Consignas](Ejercicios Modelo Lineal.pdf)
- [parte 1](parte_1/ejercicios.nb.html)
- [parte 2](parte_2/ejercicios.nb.html)
- [parte 3](parte_3/ejercicios.nb.html)
- [parte 4](parte_4/ejercicios.nb.html)
- [parte 5](parte_5/ejercicios.nb.html)


[datos parte 4](parte_4/low_birth_weight_infants.txt)